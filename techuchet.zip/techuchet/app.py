"""ИС «Учёт техники» — Flask + SQLite."""
import csv
import io
import os
import secrets
import sqlite3
from datetime import datetime
from functools import wraps

from flask import (Flask, Response, abort, flash, g, redirect, render_template,
                   request, send_from_directory, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-me-in-production")
app.config["DATABASE"] = os.environ.get("DATABASE", os.path.join(BASE_DIR, "instance", "techuchet.db"))
app.config["BACKUP_DIR"] = os.environ.get("BACKUP_DIR", os.path.join(BASE_DIR, "backups"))

STATUSES = ["В эксплуатации", "На складе", "В ремонте", "Списано"]
ROLES = {"admin": "Администратор", "operator": "Оператор", "viewer": "Наблюдатель"}
DICTS = {
    "categories": ("Категории техники", "categories"),
    "locations": ("Кабинеты и помещения", "locations"),
    "employees": ("Материально ответственные лица", "employees"),
}


# ---------- БД ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(seed=True):
    os.makedirs(os.path.dirname(app.config["DATABASE"]), exist_ok=True)
    db = sqlite3.connect(app.config["DATABASE"])
    with open(os.path.join(BASE_DIR, "schema.sql"), encoding="utf-8") as f:
        db.executescript(f.read())
    if seed and db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        db.execute("INSERT INTO users(login, full_name, role, password_hash) VALUES (?,?,?,?)",
                   ("admin", "Иванов И. И.", "admin", generate_password_hash("admin123")))
        for n in ["Компьютеры", "Ноутбуки", "Мониторы", "Принтеры и МФУ", "Проекторы", "Сетевое оборудование"]:
            db.execute("INSERT INTO categories(name) VALUES (?)", (n,))
        for n in ["Склад", "Кабинет 13", "Кабинет 16", "Кабинет 17", "Кабинет 45", "Кабинет 47", "Библиотека", "Бухгалтерия"]:
            db.execute("INSERT INTO locations(name) VALUES (?)", (n,))
        for n in ["Иванов И. И.", "Петрова А. С."]:
            db.execute("INSERT INTO employees(name) VALUES (?)", (n,))
    db.commit()
    db.close()


@app.cli.command("init-db")
def init_db_command():
    init_db()
    print("База данных инициализирована.")


# ---------- Безопасность ----------
def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.before_request
def load_user_and_check_csrf():
    g.user = None
    if "uid" in session:
        g.user = get_db().execute("SELECT * FROM users WHERE id = ?", (session["uid"],)).fetchone()
        if g.user is None:
            session.clear()
    if request.method == "POST":
        if not secrets.compare_digest(request.form.get("_csrf", ""), session.get("_csrf", "-")):
            abort(400, "Неверный токен формы")


@app.context_processor
def inject():
    return {"ROLES": ROLES, "STATUSES": STATUSES, "DICTS": DICTS}


def login_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            if g.user is None:
                return redirect(url_for("login", next=request.path))
            if roles and g.user["role"] not in roles:
                abort(403)
            return fn(*a, **kw)
        return wrapper
    return deco


def log_event(equipment_id, kind, description):
    get_db().execute(
        "INSERT INTO history(equipment_id, created_at, kind, description, user_id) VALUES (?,?,?,?,?)",
        (equipment_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), kind, description, g.user["id"]))


# ---------- Вход / выход ----------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = get_db().execute("SELECT * FROM users WHERE login = ?", (request.form["login"].strip(),)).fetchone()
        if u and check_password_hash(u["password_hash"], request.form["password"]):
            session.clear()
            session["uid"] = u["id"]
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("index"))
        flash("Неверный логин или пароль", "error")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/password", methods=["GET", "POST"])
@login_required()
def password():
    if request.method == "POST":
        if not check_password_hash(g.user["password_hash"], request.form["old"]):
            flash("Текущий пароль указан неверно", "error")
        elif len(request.form["new"]) < 6:
            flash("Новый пароль должен содержать не менее 6 символов", "error")
        else:
            get_db().execute("UPDATE users SET password_hash = ? WHERE id = ?",
                             (generate_password_hash(request.form["new"]), g.user["id"]))
            get_db().commit()
            flash("Пароль изменён", "ok")
            return redirect(url_for("index"))
    return render_template("password.html")


# ---------- Главная ----------
@app.route("/")
@login_required()
def index():
    db = get_db()
    by_status = {s: 0 for s in STATUSES}
    for r in db.execute("SELECT status, COUNT(*) c FROM equipment GROUP BY status"):
        by_status[r["status"]] = r["c"]
    total_sum = db.execute("SELECT COALESCE(SUM(price),0) FROM equipment WHERE status != 'Списано'").fetchone()[0]
    last = db.execute("""SELECT h.*, e.name, e.inv_number FROM history h
                         JOIN equipment e ON e.id = h.equipment_id ORDER BY h.id DESC LIMIT 8""").fetchall()
    return render_template("index.html", by_status=by_status, total_sum=total_sum, last=last)


# ---------- Техника ----------
def equipment_query(args):
    sql = """SELECT e.*, c.name AS category, l.name AS location, m.name AS employee
             FROM equipment e
             LEFT JOIN categories c ON c.id = e.category_id
             LEFT JOIN locations l ON l.id = e.location_id
             LEFT JOIN employees m ON m.id = e.employee_id WHERE 1=1"""
    p = []
    q = args.get("q", "").strip()
    if q:
        sql += " AND (e.name LIKE ? OR e.inv_number LIKE ? OR e.serial_number LIKE ?)"
        p += [f"%{q}%"] * 3
    for field, col in (("category", "e.category_id"), ("location", "e.location_id"), ("status", "e.status")):
        v = args.get(field, "")
        if v:
            sql += f" AND {col} = ?"
            p.append(v)
    return get_db().execute(sql + " ORDER BY e.inv_number", p).fetchall()


def dictionaries():
    db = get_db()
    return {t: db.execute(f"SELECT * FROM {t} ORDER BY name").fetchall() for t in DICTS}


@app.route("/equipment")
@login_required()
def equipment_list():
    return render_template("equipment_list.html", items=equipment_query(request.args),
                           d=dictionaries(), f=request.args)


@app.route("/equipment/export.csv")
@login_required()
def equipment_export():
    out = io.StringIO()
    w = csv.writer(out, delimiter=";")
    w.writerow(["Инв. номер", "Наименование", "Категория", "Серийный номер", "Дата покупки",
                "Стоимость", "Расположение", "Ответственный", "Статус"])
    for e in equipment_query(request.args):
        w.writerow([e["inv_number"], e["name"], e["category"], e["serial_number"], e["purchase_date"],
                    e["price"], e["location"], e["employee"], e["status"]])
    return Response("\ufeff" + out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=equipment.csv"})


def read_equipment_form():
    f = request.form
    errors = []
    inv, name = f.get("inv_number", "").strip(), f.get("name", "").strip()
    if not inv:
        errors.append("Укажите инвентарный номер")
    if not name:
        errors.append("Укажите наименование")
    try:
        price = float(f.get("price", "0").replace(",", ".") or 0)
        if price < 0:
            raise ValueError
    except ValueError:
        errors.append("Стоимость должна быть неотрицательным числом")
        price = 0
    pd = f.get("purchase_date", "").strip()
    if pd:
        try:
            datetime.strptime(pd, "%Y-%m-%d")
        except ValueError:
            errors.append("Неверная дата покупки")
    data = dict(inv_number=inv, name=name, category_id=f.get("category_id") or None,
                serial_number=f.get("serial_number", "").strip(), purchase_date=pd, price=price,
                location_id=f.get("location_id") or None, employee_id=f.get("employee_id") or None,
                status=f.get("status", STATUSES[0]), note=f.get("note", "").strip())
    if data["status"] not in STATUSES:
        errors.append("Неверный статус")
    return data, errors


@app.route("/equipment/new", methods=["GET", "POST"])
@login_required("admin", "operator")
def equipment_new():
    data = {"status": STATUSES[0], "price": 0}
    if request.method == "POST":
        data, errors = read_equipment_form()
        for e in errors:
            flash(e, "error")
        if not errors:
            db = get_db()
            try:
                cur = db.execute("""INSERT INTO equipment(inv_number,name,category_id,serial_number,purchase_date,
                    price,location_id,employee_id,status,note) VALUES
                    (:inv_number,:name,:category_id,:serial_number,:purchase_date,:price,:location_id,
                     :employee_id,:status,:note)""", data)
            except sqlite3.IntegrityError:
                flash("Техника с таким инвентарным номером уже есть", "error")
            else:
                log_event(cur.lastrowid, "Постановка на учёт", f"Поставлено на учёт, статус «{data['status']}»")
                db.commit()
                flash("Техника поставлена на учёт", "ok")
                return redirect(url_for("equipment_detail", eid=cur.lastrowid))
    return render_template("equipment_form.html", e=data, d=dictionaries(), new=True)


def get_equipment(eid):
    e = get_db().execute("""SELECT e.*, c.name AS category, l.name AS location, m.name AS employee
        FROM equipment e LEFT JOIN categories c ON c.id=e.category_id
        LEFT JOIN locations l ON l.id=e.location_id LEFT JOIN employees m ON m.id=e.employee_id
        WHERE e.id = ?""", (eid,)).fetchone()
    if e is None:
        abort(404)
    return e


@app.route("/equipment/<int:eid>")
@login_required()
def equipment_detail(eid):
    hist = get_db().execute("""SELECT h.*, u.full_name FROM history h LEFT JOIN users u ON u.id=h.user_id
                               WHERE equipment_id = ? ORDER BY h.id DESC""", (eid,)).fetchall()
    return render_template("equipment_detail.html", e=get_equipment(eid), hist=hist, d=dictionaries())


@app.route("/equipment/<int:eid>/edit", methods=["GET", "POST"])
@login_required("admin", "operator")
def equipment_edit(eid):
    e = get_equipment(eid)
    if request.method == "POST":
        data, errors = read_equipment_form()
        for er in errors:
            flash(er, "error")
        if not errors:
            data["id"] = eid
            db = get_db()
            try:
                db.execute("""UPDATE equipment SET inv_number=:inv_number,name=:name,category_id=:category_id,
                    serial_number=:serial_number,purchase_date=:purchase_date,price=:price,location_id=:location_id,
                    employee_id=:employee_id,status=:status,note=:note WHERE id=:id""", data)
            except sqlite3.IntegrityError:
                flash("Техника с таким инвентарным номером уже есть", "error")
            else:
                log_event(eid, "Редактирование", "Изменены данные карточки")
                db.commit()
                flash("Изменения сохранены", "ok")
                return redirect(url_for("equipment_detail", eid=eid))
        e = {**dict(e), **data}
    return render_template("equipment_form.html", e=e, d=dictionaries(), new=False)


@app.route("/equipment/<int:eid>/move", methods=["POST"])
@login_required("admin", "operator")
def equipment_move(eid):
    e = get_equipment(eid)
    db = get_db()
    loc, emp = request.form.get("location_id") or None, request.form.get("employee_id") or None
    nl = db.execute("SELECT name FROM locations WHERE id=?", (loc,)).fetchone() if loc else None
    ne = db.execute("SELECT name FROM employees WHERE id=?", (emp,)).fetchone() if emp else None
    db.execute("UPDATE equipment SET location_id=?, employee_id=? WHERE id=?", (loc, emp, eid))
    log_event(eid, "Перемещение",
              f"{e['location'] or '—'} → {nl['name'] if nl else '—'}; "
              f"ответственный: {e['employee'] or '—'} → {ne['name'] if ne else '—'}")
    db.commit()
    flash("Перемещение зарегистрировано", "ok")
    return redirect(url_for("equipment_detail", eid=eid))


@app.route("/equipment/<int:eid>/status", methods=["POST"])
@login_required("admin", "operator")
def equipment_status(eid):
    e = get_equipment(eid)
    status, reason = request.form.get("status"), request.form.get("reason", "").strip()
    if status not in STATUSES:
        abort(400)
    if status == "Списано" and not reason:
        flash("Для списания укажите причину", "error")
        return redirect(url_for("equipment_detail", eid=eid))
    db = get_db()
    db.execute("UPDATE equipment SET status=? WHERE id=?", (status, eid))
    log_event(eid, "Списание" if status == "Списано" else "Смена статуса",
              f"{e['status']} → {status}" + (f". Причина: {reason}" if reason else ""))
    db.commit()
    flash("Статус изменён", "ok")
    return redirect(url_for("equipment_detail", eid=eid))


# ---------- Справочники ----------
@app.route("/dict/<name>", methods=["GET", "POST"])
@login_required("admin", "operator")
def dictionary(name):
    if name not in DICTS:
        abort(404)
    db = get_db()
    if request.method == "POST":
        val = request.form.get("name", "").strip()
        if not val:
            flash("Введите название", "error")
        else:
            try:
                db.execute(f"INSERT INTO {name}(name) VALUES (?)", (val,))
                db.commit()
                flash("Запись добавлена", "ok")
            except sqlite3.IntegrityError:
                flash("Такая запись уже есть", "error")
        return redirect(url_for("dictionary", name=name))
    rows = db.execute(f"SELECT * FROM {name} ORDER BY name").fetchall()
    return render_template("dict.html", name=name, title=DICTS[name][0], rows=rows)


@app.route("/dict/<name>/<int:rid>/delete", methods=["POST"])
@login_required("admin")
def dictionary_delete(name, rid):
    if name not in DICTS:
        abort(404)
    col = {"categories": "category_id", "locations": "location_id", "employees": "employee_id"}[name]
    db = get_db()
    if db.execute(f"SELECT COUNT(*) FROM equipment WHERE {col} = ?", (rid,)).fetchone()[0]:
        flash("Нельзя удалить: запись используется в карточках техники", "error")
    else:
        db.execute(f"DELETE FROM {name} WHERE id = ?", (rid,))
        db.commit()
        flash("Запись удалена", "ok")
    return redirect(url_for("dictionary", name=name))


# ---------- Пользователи ----------
@app.route("/users", methods=["GET", "POST"])
@login_required("admin")
def users():
    db = get_db()
    if request.method == "POST":
        f = request.form
        if not f["login"].strip() or not f["full_name"].strip() or len(f["password"]) < 6 or f["role"] not in ROLES:
            flash("Заполните все поля; пароль — не менее 6 символов", "error")
        else:
            try:
                db.execute("INSERT INTO users(login, full_name, role, password_hash) VALUES (?,?,?,?)",
                           (f["login"].strip(), f["full_name"].strip(), f["role"], generate_password_hash(f["password"])))
                db.commit()
                flash("Пользователь создан", "ok")
            except sqlite3.IntegrityError:
                flash("Такой логин уже существует", "error")
        return redirect(url_for("users"))
    return render_template("users.html", rows=db.execute("SELECT * FROM users ORDER BY login").fetchall())


@app.route("/users/<int:uid>/delete", methods=["POST"])
@login_required("admin")
def user_delete(uid):
    if uid == g.user["id"]:
        flash("Нельзя удалить собственную учётную запись", "error")
    else:
        db = get_db()
        db.execute("UPDATE history SET user_id = NULL WHERE user_id = ?", (uid,))
        db.execute("DELETE FROM users WHERE id = ?", (uid,))
        db.commit()
        flash("Пользователь удалён", "ok")
    return redirect(url_for("users"))


# ---------- Резервные копии ----------
def make_backup():
    os.makedirs(app.config["BACKUP_DIR"], exist_ok=True)
    name = datetime.now().strftime("techuchet_%Y%m%d_%H%M%S.db")
    dst = sqlite3.connect(os.path.join(app.config["BACKUP_DIR"], name))
    src = sqlite3.connect(app.config["DATABASE"])
    src.backup(dst)
    src.close()
    dst.close()
    return name


@app.route("/backups", methods=["GET", "POST"])
@login_required("admin")
def backups():
    if request.method == "POST":
        flash(f"Резервная копия создана: {make_backup()}", "ok")
        return redirect(url_for("backups"))
    d = app.config["BACKUP_DIR"]
    files = sorted(os.listdir(d), reverse=True) if os.path.isdir(d) else []
    files = [(f, os.path.getsize(os.path.join(d, f)) // 1024) for f in files if f.endswith(".db")]
    return render_template("backups.html", files=files)


@app.route("/backups/<path:fname>")
@login_required("admin")
def backup_download(fname):
    return send_from_directory(app.config["BACKUP_DIR"], fname, as_attachment=True)


@app.errorhandler(403)
def e403(_):
    return render_template("error.html", code=403, text="Недостаточно прав для выполнения действия"), 403


@app.errorhandler(404)
def e404(_):
    return render_template("error.html", code=404, text="Страница не найдена"), 404


if __name__ == "__main__":
    init_db()
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
