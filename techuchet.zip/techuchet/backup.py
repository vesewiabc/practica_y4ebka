"""Резервное копирование и восстановление БД.
  python backup.py            — создать копию (хранятся последние 30)
  python backup.py restore <файл.db> — восстановить из копии
"""
import os
import shutil
import sys

from app import app, make_backup

KEEP = 30

if len(sys.argv) >= 3 and sys.argv[1] == "restore":
    src = sys.argv[2]
    if not os.path.isfile(src):
        sys.exit(f"Файл не найден: {src}")
    if os.path.isfile(app.config["DATABASE"]):
        shutil.copy2(app.config["DATABASE"], app.config["DATABASE"] + ".before_restore")
    shutil.copy2(src, app.config["DATABASE"])
    print("База данных восстановлена из", src)
else:
    print("Создана копия:", make_backup())
    d = app.config["BACKUP_DIR"]
    old = sorted(f for f in os.listdir(d) if f.endswith(".db"))[:-KEEP]
    for f in old:
        os.remove(os.path.join(d, f))
